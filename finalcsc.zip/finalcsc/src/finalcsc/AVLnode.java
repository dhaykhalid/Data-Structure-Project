package finalcsc;

public class AVLnode<K extends Comparable<K>, T> {
    public K key;
    public T data;
    public int height;
    public AVLnode<K,T> left, right;

    public AVLnode(K key, T data) {
        this.key = key;
        this.data = data;
        this.height = 1;
        this.left = null;
               this.right = null;
    }
}
