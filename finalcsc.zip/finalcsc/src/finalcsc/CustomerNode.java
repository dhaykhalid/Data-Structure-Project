package finalcsc;

public class CustomerNode {

    public int customerID;
    public String customerName;
    public String email;

    // List of reviews by this customer
    public LinkedList<ReviewNode> reviews = new LinkedList<>();

    public CustomerNode(int id, String name, String email) {
        this.customerID = id;
        this.customerName = name;
        this.email = email;
    }

    public void displayBasic() {
        System.out.println("----------------------------------");
        System.out.println("Customer ID: " + customerID);
        System.out.println("Name       : " + customerName);
        System.out.println("Email      : " + email);
        System.out.println("----------------------------------");
    }

    @Override
    public String toString() {
        return customerID + " - " + customerName;
    }
}
