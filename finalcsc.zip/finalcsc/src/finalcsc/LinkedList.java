package finalcsc;

public class LinkedList<T> {

    private LinkedListNode<T> head;

    public LinkedList() {
        head = null;
    }

    public boolean empty() {
        return head == null;
    }

    public void addLast(T value) {
        LinkedListNode<T> newNode = new LinkedListNode<>(value);

        if (head == null) {
            head = newNode;
            return;
        }

        LinkedListNode<T> p = head;
        while (p.next != null)
            p = p.next;

        p.next = newNode;
    }

    public void printList() {
        if (empty()) {
            System.out.println("List is empty.");
            return;
        }

        LinkedListNode<T> p = head;
        while (p != null) {
            System.out.println(p.data.toString());
            p = p.next;
        }
    }
}
