package finalcsc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

public class OrderDataStructure {

    private AVLMap<Integer, OrderNode> orders = new AVLMap<>();
    private int lastOrderId = 1000;   // نبدأ من 1001

    // ========== تحميل الأوردرز من CSV ==========

    public void loadOrders(String filename, CustomerDataStructure customersDS) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String line;

            // نتجاهل الهيدر (أول سطر)
            br.readLine();

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length < 3) continue;

                if (!parts[0].trim().matches("\\d+")) continue;

                int oid = Integer.parseInt(parts[0].trim());
                int cid = Integer.parseInt(parts[1].trim());

                // نبحث عن التاريخ في باقي الأعمدة
                String dateStr = null;
                String status = "Processing";

                for (int i = 2; i < parts.length; i++) {
                    String token = parts[i].trim();
                    if (token.matches("\\d{4}-\\d{2}-\\d{2}")) {
                        dateStr = token;
                        if (i + 1 < parts.length) {
                            status = parts[i + 1].trim();
                        }
                        break;
                    }
                }

                if (dateStr == null) continue;

                LocalDate date = LocalDate.parse(dateStr);

                if (customersDS.searchById(cid) == null) continue;

                OrderNode o = new OrderNode(oid, cid, date, status);
                orders.insert(oid, o);

                if (oid > lastOrderId) {
                    lastOrderId = oid;
                }
            }

            System.out.println("Orders loaded from " + filename);

        } catch (IOException e) {
            System.out.println("Error reading orders file: " + e.getMessage());
        }
    }

    // ========== إنشاء أوردر جديد مع اختيار المنتج والكمية ==========

    public void placeNewOrder(int customerId,
                              ProductDataStructure productsDS,
                              CustomerDataStructure customersDS) {

        Scanner input = new Scanner(System.in);

        // تأكد أن العميل موجود
        CustomerNode c = customersDS.searchById(customerId);
        if (c == null) {
            System.out.println("Customer not found. Order cancelled.");
            return;
        }

        // إدخال المنتج
        System.out.print("Enter product ID to order: ");
        String linePid = input.nextLine();
        int productId;
        try {
            productId = Integer.parseInt(linePid.trim());
        } catch (Exception e) {
            System.out.println("Invalid product ID. Order cancelled.");
            return;
        }

        ProductNode p = productsDS.searchProductById(productId);
        if (p == null) {
            System.out.println("Product not found. Order cancelled.");
            return;
        }

        // إدخال الكمية
        System.out.print("Enter quantity: ");
        String lineQty = input.nextLine();
        int qty;
        try {
            qty = Integer.parseInt(lineQty.trim());
        } catch (Exception e) {
            System.out.println("Invalid quantity. Order cancelled.");
            return;
        }

        if (qty <= 0) {
            System.out.println("Quantity must be greater than 0. Order cancelled.");
            return;
        }

        if (p.getStock() < qty) {
            System.out.println("Not enough stock. Available = " + p.getStock());
            return;
        }

        // خصم من الستوك
        int newStock = p.getStock() - qty;
        p.setStock(newStock);

        // توليد orderId جديد تسلسلي
        lastOrderId = lastOrderId + 1;
        int newOrderId = lastOrderId;

        LocalDate today = LocalDate.now();
        String status = "Placed";

        OrderNode order = new OrderNode(newOrderId, customerId, productId, qty, today, status);
        orders.insert(newOrderId, order);

        System.out.println("Order created successfully:");
        order.display();
    }

    // ========== عمليات أخرى على الأوردرز ==========

    public void cancelOrder(int orderId) {
        boolean removed = orders.delete(orderId);
        if (removed) {
            System.out.println("Order cancelled.");
        } else {
            System.out.println("Order not found.");
        }
    }

    public void updateOrderStatus(int orderId, String newStatus) {
        boolean found = orders.find(orderId);
        if (!found) {
            System.out.println("Order not found.");
            return;
        }
        OrderNode o = orders.retrieve();
        o.setStatus(newStatus);
        System.out.println("Order status updated.");
    }

    public OrderNode searchById(int orderId) {
        boolean found = orders.find(orderId);
        if (found) {
            return orders.retrieve();
        } else {
            return null;
        }
    }

    public void displayOrdersForCustomer(int customerId) {
        System.out.println("Orders for customer " + customerId + ":");
        displayOrdersForCustomerRec(orders.getRoot(), customerId);
    }

    private void displayOrdersForCustomerRec(AVLnode<Integer, OrderNode> node, int customerId) {
        if (node == null) return;

        displayOrdersForCustomerRec(node.left, customerId);

        OrderNode o = node.data;
        if (o.getCustomerId() == customerId) {
            o.display();
        }

        displayOrdersForCustomerRec(node.right, customerId);
    }

    public void findOrdersBetweenDates(LocalDate start, LocalDate end) {
        System.out.println("Orders between " + start + " and " + end + ":");
        findOrdersBetweenDatesRec(orders.getRoot(), start, end);
    }

    private void findOrdersBetweenDatesRec(AVLnode<Integer, OrderNode> node,
                                           LocalDate start, LocalDate end) {
        if (node == null) return;

        findOrdersBetweenDatesRec(node.left, start, end);

        OrderNode o = node.data;
        LocalDate d = o.getOrderDate();
        if ((d.isEqual(start) || d.isAfter(start)) &&
            (d.isEqual(end)   || d.isBefore(end))) {
            o.display();
        }

        findOrdersBetweenDatesRec(node.right, start, end);
    }
}
