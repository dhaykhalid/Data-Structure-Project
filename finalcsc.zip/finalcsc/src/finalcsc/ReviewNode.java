package finalcsc;

public class ReviewNode {

    public int reviewID;
    public int productID;
    public int customerID;
    public int rating;
    public String comment;

    public ReviewNode(int rid, int pid, int cid, int rating, String comment) {
        this.reviewID = rid;
        this.productID = pid;
        this.customerID = cid;
        this.rating = rating;
        this.comment = comment;
    }

    @Override
    public String toString() {
        return "Review " + reviewID + " | Product: " + productID + 
               " | Customer: " + customerID + " | Rating: " + rating +
               " | " + comment;
    }
}
