package finalcsc;

public class AVLMap<K extends Comparable<K>, T> {

    private AVLnode<K, T> root;
    private AVLnode<K, T> current;

    public AVLMap() {
        root = null;
        current = null;
    }

    public AVLnode<K, T> getRoot() {
        return root;
    }

    public boolean empty() {
        if (root == null) {
            return true;
        } else {
            return false;
        }
    }

    public T retrieve() {
        if (current != null) {
            return current.data;
        } else {
            return null;
        }
    }

    // ================= HEIGHT =================

    private int height(AVLnode<K, T> n) {
        if (n == null) {
            return 0;
        } else {
            return n.height;
        }
    }

    private void updateHeight(AVLnode<K, T> n) {
        int hl = height(n.left);
        int hr = height(n.right);
        if (hl > hr) {
            n.height = hl + 1;
        } else {
            n.height = hr + 1;
        }
    }

    private int getBalance(AVLnode<K, T> n) {
        int hl = height(n.left);
        int hr = height(n.right);
        return hl - hr;
    }

    // ================= ROTATIONS ================

    private AVLnode<K, T> rightRotate(AVLnode<K, T> y) {
        AVLnode<K, T> x = y.left;
        AVLnode<K, T> t2 = x.right;

        x.right = y;
        y.left = t2;

        updateHeight(y);
        updateHeight(x);

        return x;
    }

    private AVLnode<K, T> leftRotate(AVLnode<K, T> x) {
        AVLnode<K, T> y = x.right;
        AVLnode<K, T> t2 = y.left;

        y.left = x;
        x.right = t2;

        updateHeight(x);
        updateHeight(y);

        return y;
    }

    // ================= INSERT ===================

    public boolean insert(K key, T data) {
        root = insertRec(root, key, data);
        find(key); // عشان current يتحدث
        return true;
    }

    private AVLnode<K, T> insertRec(AVLnode<K, T> node, K key, T data) {

        if (node == null) {
            AVLnode<K, T> newNode = new AVLnode<K, T>(key, data);
            return newNode;
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left = insertRec(node.left, key, data);
        } else if (cmp > 0) {
            node.right = insertRec(node.right, key, data);
        } else {
            // نفس المفتاح → لا نغيّر شيء
            return node;
        }

        // تحديث الارتفاع
        updateHeight(node);

        // التوازن
        int balance = getBalance(node);

        // LL
        if (balance > 1 && key.compareTo(node.left.key) < 0) {
            return rightRotate(node);
        }

        // RR
        if (balance < -1 && key.compareTo(node.right.key) > 0) {
            return leftRotate(node);
        }

        // LR
        if (balance > 1 && key.compareTo(node.left.key) > 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // RL
        if (balance < -1 && key.compareTo(node.right.key) < 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    // ================= FIND =====================

    public boolean find(K key) {
        AVLnode<K, T> p = root;

        while (p != null) {
            int cmp = key.compareTo(p.key);

            if (cmp == 0) {
                current = p;
                return true;
            } else if (cmp < 0) {
                p = p.left;
            } else {
                p = p.right;
            }
        }

        current = null;
        return false;
    }

    // ================= DELETE ===================

    public boolean delete(K key) {
        if (!find(key)) {
            return false;
        }
        root = deleteRec(root, key);
        current = null;
        return true;
    }

    private AVLnode<K, T> deleteRec(AVLnode<K, T> node, K key) {
        if (node == null) {
            return null;
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left = deleteRec(node.left, key);
        } else if (cmp > 0) {
            node.right = deleteRec(node.right, key);
        } else {
            // هذا هو النود المطلوب حذفه
            if (node.left == null && node.right == null) {
                node = null;
            } else if (node.left == null) {
                node = node.right;
            } else if (node.right == null) {
                node = node.left;
            } else {
                // عقدتين أبناء → نجيب الـ inorder successor
                AVLnode<K, T> successor = minValueNode(node.right);
                node.key = successor.key;
                node.data = successor.data;
                node.right = deleteRec(node.right, successor.key);
            }
        }

        if (node == null) {
            return null;
        }

        // تحديث الارتفاع بعد الحذف
        updateHeight(node);

        int balance = getBalance(node);

        // LL
        if (balance > 1 && getBalance(node.left) >= 0) {
            return rightRotate(node);
        }

        // LR
        if (balance > 1 && getBalance(node.left) < 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // RR
        if (balance < -1 && getBalance(node.right) <= 0) {
            return leftRotate(node);
        }

        // RL
        if (balance < -1 && getBalance(node.right) > 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    private AVLnode<K, T> minValueNode(AVLnode<K, T> node) {
        AVLnode<K, T> currentNode = node;
        while (currentNode.left != null) {
            currentNode = currentNode.left;
        }
        return currentNode;
    }
}
