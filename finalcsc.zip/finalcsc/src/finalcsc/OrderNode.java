package finalcsc;

import java.time.LocalDate;

public class OrderNode {

    private int orderId;
    private int customerId;
    private int productId;
    private int quantity;
    private LocalDate orderDate;
    private String status;

    // Constructor كامل (للأوردر الجديد من المستخدم)
    public OrderNode(int orderId, int customerId, int productId, int quantity,
                     LocalDate orderDate, String status) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.productId = productId;
        this.quantity = quantity;
        this.orderDate = orderDate;
        this.status = status;
    }

    // Constructor مبسط لتحميل من CSV (لو ما عندك productId/quantity في الملف)
    public OrderNode(int orderId, int customerId, LocalDate orderDate, String status) {
        this(orderId, customerId, -1, 0, orderDate, status);
    }

    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getProductId() {
        return productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void display() {
        System.out.println("-------------------------------------------------");
        System.out.println("Order ID   : " + orderId);
        System.out.println("Customer ID: " + customerId);
        if (productId != -1) {
            System.out.println("Product ID : " + productId);
            System.out.println("Quantity   : " + quantity);
        }
        System.out.println("Date       : " + orderDate);
        System.out.println("Status     : " + status);
        System.out.println("-------------------------------------------------");
    }
}
