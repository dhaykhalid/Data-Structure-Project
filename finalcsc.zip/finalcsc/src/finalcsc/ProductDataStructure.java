package finalcsc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ProductDataStructure {

    private AVLMap<Integer, ProductNode> products = new AVLMap<>();

    // ====== تحميل المنتجات من ملف CSV ======
    public void loadProducts(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String line;

            // نحذف الهيدر لو موجود
            // مثال: productId,productName,price,stock
            br.readLine();

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length < 4) continue;

                if (!parts[0].trim().matches("\\d+")) continue;

                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();
                double price = Double.parseDouble(parts[2].trim());
                int stock = Integer.parseInt(parts[3].trim());

                ProductNode p = new ProductNode(id, name, price, stock);
                addProduct(p);
            }

            System.out.println("Products loaded from " + filename);

        } catch (IOException e) {
            System.out.println("Error reading products file: " + e.getMessage());
        }
    }

    // ====== عمليات أساسية على المنتجات ======

    public void addProduct(ProductNode p) {
        products.insert(p.productID, p);
        System.out.println("Product added.");
    }

    public void removeProduct(int id) {
        boolean removed = products.delete(id);
        if (removed) {
            System.out.println("Product removed.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void updateProduct(int id, String name, double price, int stock) {
        boolean found = products.find(id);
        if (!found) {
            System.out.println("Product not found.");
            return;
        }

        ProductNode p = products.retrieve();
        p.productName = name;
        p.price = price;
        p.setStock(stock);

        System.out.println("Product updated.");
    }

    // الاسم اللي استعملناه مع الأوردر
    public ProductNode searchProductById(int id) {
        boolean found = products.find(id);
        if (found) {
            return products.retrieve();
        } else {
            return null;
        }
    }

    // الاسم القديم لو المين يستعمله
    public ProductNode SearchProductByid(int id) {
        return searchProductById(id);
    }

    public void searchProductsByName(String key) {
        String lowerKey = key.toLowerCase();
        searchNameRec(products.getRoot(), lowerKey);
    }

    private void searchNameRec(AVLnode<Integer, ProductNode> node, String key) {
        if (node == null) return;

        searchNameRec(node.left, key);

        ProductNode p = node.data;
        if (p.productName.toLowerCase().contains(key)) {
            p.display();
        }

        searchNameRec(node.right, key);
    }

    public void listProductsInPriceRange(double min, double max) {
        listRangeRec(products.getRoot(), min, max);
    }

    private void listRangeRec(AVLnode<Integer, ProductNode> node, double min, double max) {
        if (node == null) return;

        listRangeRec(node.left, min, max);

        ProductNode p = node.data;
        if (p.price >= min && p.price <= max) {
            p.display();
        }

        listRangeRec(node.right, min, max);
    }

    public void listOutOfStock() {
        Counter c = new Counter();
        outOfStockRec(products.getRoot(), c);
        if (c.count == 0) {
            System.out.println("All products are in stock.");
        }
    }

    private void outOfStockRec(AVLnode<Integer, ProductNode> node, Counter c) {
        if (node == null) return;

        outOfStockRec(node.left, c);

        ProductNode p = node.data;
        if (p.getStock() == 0) {
            p.display();
            c.count++;
        }

        outOfStockRec(node.right, c);
    }

    private static class Counter {
        int count = 0;
    }

    public void displayAllProducts() {
        displayRec(products.getRoot());
    }

    private void displayRec(AVLnode<Integer, ProductNode> node) {
        if (node == null) return;

        displayRec(node.left);
        node.data.display();
        displayRec(node.right);
    }
}
