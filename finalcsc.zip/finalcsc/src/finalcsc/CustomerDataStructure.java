package finalcsc;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class CustomerDataStructure {

    private AVLMap<Integer, CustomerNode> customers = new AVLMap<>();

    public void addCustomer(CustomerNode c) {
        customers.insert(c.customerID, c);
        System.out.println("Customer added.");
    }

    public CustomerNode searchById(int id) {
        if (customers.find(id))
            return customers.retrieve();
        return null;
    }

    public void listCustomersAlphabetically() {
        listAlphaRec(customers.getRoot());
    }

    private void listAlphaRec(AVLnode<Integer,CustomerNode> node) {
        if (node == null) return;
        listAlphaRec(node.left);
        node.data.displayBasic();
        listAlphaRec(node.right);
    }

    public void displayAllCustomers() {
        listAlphaRec(customers.getRoot());
    }

    public void printReviewsForCustomer(int cid) {
        CustomerNode c = searchById(cid);
        if (c == null) {
            System.out.println("Customer not found.");
            return;
        }
        System.out.println("Reviews for " + c.customerName);
        c.reviews.printList();
    }
    public void loadCustomers(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Skip header line
                if (line.toLowerCase().startsWith("customer")) continue;

                String[] parts = line.split(",");
                if (parts.length < 3) continue;

                // لو السطر فيه كلمات بدل أرقام → نتجاهله
                if (!parts[0].matches("\\d+")) continue;

                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();
                String email = parts[2].trim();

                CustomerNode c = new CustomerNode(id, name, email);
                addCustomer(c);
            }

            System.out.println("Customers loaded from " + filename);

        } catch (IOException e) {
            System.out.println("Error reading customers file: " + e.getMessage());
        }
    }

    
}
