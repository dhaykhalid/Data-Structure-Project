package finalcsc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ReviewDataStructure {

    private AVLMap<Integer, ReviewNode> reviews = new AVLMap<>();
    private ProductDataStructure products;
    private CustomerDataStructure customers;

    public void setAllProducts(ProductDataStructure p) {
        products = p;
    }

    public void setAllCustomers(CustomerDataStructure c) {
        customers = c;
    }

    // =================== تحميل من الملف ===================

    public void loadReviews(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // تخطي الهيدر مثل: reviewId,productId,customerId,rating,comment
                String lower = line.toLowerCase();
                if (lower.startsWith("review")) continue;

                String[] parts = line.split(",");
                if (parts.length < 4) continue;

                String idStr = parts[0].trim();
                if (!idStr.matches("\\d+")) continue;

                int rid    = Integer.parseInt(parts[0].trim());
                int pid    = Integer.parseInt(parts[1].trim());
                int cid    = Integer.parseInt(parts[2].trim());
                int rating = Integer.parseInt(parts[3].trim());

                String comment = "";
                if (parts.length > 4) {
                    StringBuilder sb = new StringBuilder(parts[4].trim());
                    int i = 5;
                    while (i < parts.length) {
                        sb.append(",");
                        sb.append(parts[i].trim());
                        i++;
                    }
                    comment = sb.toString();
                }

                ReviewNode r = new ReviewNode(rid, pid, cid, rating, comment);
                addReview(r);
            }

            System.out.println("Reviews loaded from " + filename);

        } catch (IOException e) {
            System.out.println("Error reading reviews file: " + e.getMessage());
        }
    }

    // =================== عمليات أساسية ====================

    public void addReview(ReviewNode r) {
        // لازم المنتج والعميل يكونون موجودين
        ProductNode p = products.SearchProductByid(r.productID);
        CustomerNode c = customers.searchById(r.customerID);

        if (p == null) {
            System.out.println("Product not found, review ignored.");
            return;
        }
        if (c == null) {
            System.out.println("Customer not found, review ignored.");
            return;
        }

        reviews.insert(r.reviewID, r);

        // نربط الريفيو مع المنتج والعميل (لنكد لست)
        p.reviews.addLast(r);
        c.reviews.addLast(r);

        System.out.println("Review added.");
    }

    public void editReview(int rid, int rating, String comment) {
        boolean found = reviews.find(rid);
        if (!found) {
            System.out.println("Review not found.");
            return;
        }

        ReviewNode r = reviews.retrieve();
        r.rating = rating;
        r.comment = comment;

        System.out.println("Review updated.");
    }

    // =================== Average Rating ====================

    private static class SumCount {
        double sum;
        int count;
    }

    public void getAverageRating(int pid) {
        SumCount sc = new SumCount();
        computeAverageRec(reviews.getRoot(), pid, sc);

        if (sc.count == 0) {
            System.out.println("No reviews for this product.");
        } else {
            double avg = sc.sum / sc.count;
            System.out.println("Average rating for product " + pid + " = " + avg);
        }
    }

    private void computeAverageRec(AVLnode<Integer, ReviewNode> node, int pid, SumCount sc) {
        if (node == null) return;

        computeAverageRec(node.left, pid, sc);

        ReviewNode r = node.data;
        if (r.productID == pid) {
            sc.sum = sc.sum + r.rating;
            sc.count = sc.count + 1;
        }

        computeAverageRec(node.right, pid, sc);
    }

    // =================== إحصائيات المنتجات =================

    private static class ProductStats {
        int productId;
        int totalRating;
        int count;
        int reviewCount;
    }

    private ProductStats findStats(ArrayList<ProductStats> list, int pid) {
        int i = 0;
        while (i < list.size()) {
            ProductStats ps = list.get(i);
            if (ps.productId == pid) return ps;
            i++;
        }
        ProductStats ps = new ProductStats();
        ps.productId = pid;
        ps.totalRating = 0;
        ps.count = 0;
        ps.reviewCount = 0;
        list.add(ps);
        return ps;
    }

    private void collectStats(AVLnode<Integer, ReviewNode> node, ArrayList<ProductStats> list) {
        if (node == null) return;

        collectStats(node.left, list);

        ReviewNode r = node.data;
        ProductStats ps = findStats(list, r.productID);
        ps.totalRating = ps.totalRating + r.rating;
        ps.count = ps.count + 1;
        ps.reviewCount = ps.reviewCount + 1;

        collectStats(node.right, list);
    }

    // ============ 4) Top 3 Highest AVG Rated Products ======

    public void suggestTop3Products() {
        ArrayList<ProductStats> stats = new ArrayList<>();
        collectStats(reviews.getRoot(), stats);

        if (stats.isEmpty()) {
            System.out.println("No reviews in the system.");
            return;
        }

        // نحسب الـ average لكل منتج
        int i = 0;
        while (i < stats.size()) {
            ProductStats ps = stats.get(i);
            if (ps.count > 0) {
                // نحفظ الـ average بشكل مؤقت في totalRating كـ double مضروب مثلاً
                // لكن أسهل أننا نخليه كما هو ونحسبه وقت الطباعة
            }
            i++;
        }

        // نرتبهم يدويًا حسب average (Bubble sort بسيط)
        int n = stats.size();
        int pass = 0;
        while (pass < n - 1) {
            int j = 0;
            while (j < n - pass - 1) {
                ProductStats a = stats.get(j);
                ProductStats b = stats.get(j + 1);

                double avgA = 0.0;
                if (a.count > 0) avgA = (double) a.totalRating / a.count;

                double avgB = 0.0;
                if (b.count > 0) avgB = (double) b.totalRating / b.count;

                if (avgB > avgA) {
                    stats.set(j, b);
                    stats.set(j + 1, a);
                }
                j++;
            }
            pass++;
        }

        System.out.println("Top 3 Highest AVG Rated Products:");
        int printed = 0;
        int idx = 0;
        while (idx < stats.size() && printed < 3) {
            ProductStats ps = stats.get(idx);
            if (ps.count > 0) {
                double avg = (double) ps.totalRating / ps.count;
                ProductNode p = products.SearchProductByid(ps.productId);
                if (p != null) {
                    System.out.println("Product ID: " + ps.productId +
                                       "  Avg Rating: " + avg +
                                       "  #Reviews: " + ps.reviewCount);
                    p.display();
                    printed = printed + 1;
                }
            }
            idx++;
        }

        if (printed == 0) {
            System.out.println("No products with reviews.");
        }
    }

    // ============ 5) Top 3 Most Reviewed Products ==========

    public void showTop3MostReviewed() {
        ArrayList<ProductStats> stats = new ArrayList<>();
        collectStats(reviews.getRoot(), stats);

        if (stats.isEmpty()) {
            System.out.println("No reviews in the system.");
            return;
        }

        // ترتيب حسب عدد الـ reviews
        int n = stats.size();
        int pass = 0;
        while (pass < n - 1) {
            int j = 0;
            while (j < n - pass - 1) {
                ProductStats a = stats.get(j);
                ProductStats b = stats.get(j + 1);

                if (b.reviewCount > a.reviewCount) {
                    stats.set(j, b);
                    stats.set(j + 1, a);
                }
                j++;
            }
            pass++;
        }

        System.out.println("Top 3 Most Reviewed Products:");
        int printed = 0;
        int idx = 0;
        while (idx < stats.size() && printed < 3) {
            ProductStats ps = stats.get(idx);
            if (ps.reviewCount > 0) {
                ProductNode p = products.SearchProductByid(ps.productId);
                if (p != null) {
                    System.out.println("Product ID: " + ps.productId +
                                       "  #Reviews: " + ps.reviewCount);
                    p.display();
                    printed = printed + 1;
                }
            }
            idx++;
        }

        if (printed == 0) {
            System.out.println("No products with reviews.");
        }
    }

    // == 6) Common products with avg rating >=4 between 2 customers ==

    public void commonProductsWithRatingAtLeast4BetweenCustomers(int c1, int c2) {

        // أولاً: نبني إحصائيات products لتحديد الـ average
        ArrayList<ProductStats> stats = new ArrayList<>();
        collectStats(reviews.getRoot(), stats);

        // ثانياً: نجمع المنتجات اللي قيمها كل عميل بـ 4 أو أكثر
        ArrayList<Integer> list1 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        collectCustomerHighRated(reviews.getRoot(), c1, c2, list1, list2);

        // ثالثاً: نجيب المنتجات المشتركة
        ArrayList<Integer> common = new ArrayList<>();
        int i = 0;
        while (i < list1.size()) {
            int pid = list1.get(i);
            int j = 0;
            boolean found = false;
            while (j < list2.size()) {
                if (list2.get(j) == pid) {
                    found = true;
                }
                j++;
            }
            if (found) {
                common.add(pid);
            }
            i++;
        }

        if (common.isEmpty()) {
            System.out.println("No common products with rating >= 4 by both customers.");
            return;
        }

        // رابعاً: نطبع فقط المنتجات اللي متوسط تقييمها >= 4
        System.out.println("Common products with average rating >= 4 between customers "
                           + c1 + " and " + c2 + ":");

        boolean printedSomething = false;

        int k = 0;
        while (k < common.size()) {
            int pid = common.get(k);

            ProductStats ps = null;
            int t = 0;
            while (t < stats.size()) {
                if (stats.get(t).productId == pid) {
                    ps = stats.get(t);
                }
                t++;
            }

            if (ps != null && ps.count > 0) {
                double avg = (double) ps.totalRating / ps.count;
                if (avg >= 4.0) {
                    ProductNode p = products.SearchProductByid(pid);
                    if (p != null) {
                        System.out.println("Product ID: " + pid + "  Avg Rating: " + avg);
                        p.display();
                        printedSomething = true;
                    }
                }
            }

            k++;
        }

        if (!printedSomething) {
            System.out.println("No common products with average rating >= 4.");
        }
    }

    private void collectCustomerHighRated(AVLnode<Integer, ReviewNode> node,
                                          int c1, int c2,
                                          ArrayList<Integer> list1,
                                          ArrayList<Integer> list2) {
        if (node == null) return;

        collectCustomerHighRated(node.left, c1, c2, list1, list2);

        ReviewNode r = node.data;
        if (r.rating >= 4) {
            if (r.customerID == c1 && !list1.contains(r.productID)) {
                list1.add(r.productID);
            }
            if (r.customerID == c2 && !list2.contains(r.productID)) {
                list2.add(r.productID);
            }
        }

        collectCustomerHighRated(node.right, c1, c2, list1, list2);
    }

    // ======== مستخدمة من منيو الـ Products ========

    public void listCustomersWhoReviewedProductByRating(int pid) {
        listByRatingRec(reviews.getRoot(), pid);
    }

    private void listByRatingRec(AVLnode<Integer, ReviewNode> node, int pid) {
        if (node == null) return;

        listByRatingRec(node.left, pid);

        ReviewNode r = node.data;
        if (r.productID == pid) {
            System.out.println("Customer " + r.customerID + " | Rating: " + r.rating);
        }

        listByRatingRec(node.right, pid);
    }

    public void listCustomersWhoReviewedProductByCustomerId(int pid) {
        listByCustomerIdRec(reviews.getRoot(), pid);
    }

    private void listByCustomerIdRec(AVLnode<Integer, ReviewNode> node, int pid) {
        if (node == null) return;

        listByCustomerIdRec(node.left, pid);

        ReviewNode r = node.data;
        if (r.productID == pid) {
            System.out.println("Customer " + r.customerID);
        }

        listByCustomerIdRec(node.right, pid);
    }
}
