package finalcsc;

public class ProductNode {

    public int productID;
    public String productName;
    public double price;
    private int stock;   // الكمية في المخزون

    // قائمة الريفيوز (لو عندك LinkedList جاهزة)
    public LinkedList<ReviewNode> reviews = new LinkedList<>();

    public ProductNode(int id, String name, double price, int stock) {
        this.productID = id;
        this.productName = name;
        this.price = price;
        this.stock = stock;
    }

    // ====== Getters / Setters ======

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    // لو حابة تضيفين getters ثانية:
    public int getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    // ====== طباعة ======

    public void display() {
        System.out.println("-------------------------------------------------");
        System.out.println("Product ID   : " + productID);
        System.out.println("Name         : " + productName);
        System.out.println("Price        : " + price);
        System.out.println("Stock        : " + stock);
        System.out.println("-------------------------------------------------");
    }

    @Override
    public String toString() {
        return productID + " - " + productName + " (Price: " + price + ", Stock: " + stock + ")";
    }
}
