package finalcsc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ECommerceSystem {

    private static final Scanner input = new Scanner(System.in);

    // هياكل البيانات
    private static ProductDataStructure productsDS = new ProductDataStructure();
    private static CustomerDataStructure customersDS = new CustomerDataStructure();
    private static OrderDataStructure ordersDS = new OrderDataStructure();
    private static ReviewDataStructure reviewsDS = new ReviewDataStructure();

    public static void main(String[] args) {

        System.out.println("loading data from CSVs files");
        System.out.println("****************************");

        // تحميل البيانات من الملفات
        customersDS.loadCustomers("customers.csv");
        productsDS.loadProducts("products.csv");
        ordersDS.loadOrders("orders.csv", customersDS);

        reviewsDS.setAllProducts(productsDS);
        reviewsDS.setAllCustomers(customersDS);
        reviewsDS.loadReviews("reviews.csv");

        int choice;
        do {
            printMainMenu();
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    productsMenu();
                    break;
                case 2:
                    customersMenu();
                    break;
                case 3:
                    ordersMenu();
                    break;
                case 4:
                    reviewsMenu();
                    break;
              
                case 5:
                    System.out.println("Exiting program. Bye :)");
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }

        } while (choice != 5 && choice != 6);
    }

    // =========================== Main Menu =============================

    private static void printMainMenu() {
        System.out.println();
        System.out.println("****************************");
        System.out.println("1. Products");
        System.out.println("2. Customers");
        System.out.println("3. Orders");
        System.out.println("4. Reviews");
        System.out.println("5. Exit");
        System.out.println("****************************");
    }

    // =========================== Products Menu =========================

    private static void productsMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println("1. Add new product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product (name, price, stock)");
            System.out.println("4. Search by ID");
            System.out.println("5. Search products by name");
            System.out.println("6. List All Products Within a Price Range(minPrice,maxPrice)");
            System.out.println("7. Track All out-of-stock products");
            System.out.println("8. Display All Customers Who Reviewed specific product sorted by RATING");
            System.out.println("9. Display All Customers Who Reviewed specific product sorted by CUSTOMER ID.");
            System.out.println("10. Print all products.");
            System.out.println("11. Return Main menu");
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1: { // Add new product
                    int id = readInt("Enter product ID: ");
                    System.out.print("Enter product name: ");
                    String name = input.nextLine();
                    double price = readDouble("Enter price: ");
                    int stock = readInt("Enter stock: ");
                    ProductNode p = new ProductNode(id, name, price, stock);
                    productsDS.addProduct(p);
                    break;
                }

                case 2: { // Remove product
                    int id = readInt("Enter product ID to remove: ");
                    productsDS.removeProduct(id); // حاليًا تطبع رسالة فقط (مافي delete حقيقي)
                    break;
                }

                case 3: { // Update product
                    int id = readInt("Enter product ID to update: ");
                    System.out.print("Enter new name: ");
                    String name = input.nextLine();
                    double price = readDouble("Enter new price: ");
                    int stock = readInt("Enter new stock: ");
                    productsDS.updateProduct(id, name, price, stock);
                    break;
                }

                case 4: { // Search by ID
                    int id = readInt("Enter product ID: ");
                    ProductNode p = productsDS.SearchProductByid(id);
                    if (p == null) System.out.println("Product not found.");
                    else p.display();
                    break;
                }

                case 5: { // Search products by name
                    System.out.print("Enter part of product name: ");
                    String key = input.nextLine();
                    productsDS.searchProductsByName(key);
                    break;
                }

                case 6: { // List products in price range
                    double min = readDouble("Enter min price: ");
                    double max = readDouble("Enter max price: ");
                    productsDS.listProductsInPriceRange(min, max);
                    break;
                }

                case 7: // Track all out-of-stock products
                    productsDS.listOutOfStock();
                    break;

                case 8: { // customers who reviewed product by rating
                    int pid = readInt("Enter product ID: ");
                    reviewsDS.listCustomersWhoReviewedProductByRating(pid);
                    break;
                }

                case 9: { // customers who reviewed product by customer ID
                    int pid = readInt("Enter product ID: ");
                    reviewsDS.listCustomersWhoReviewedProductByCustomerId(pid);
                    break;
                }

                case 10: // Print all products
                    productsDS.displayAllProducts();
                    break;

                case 11:
                    // Return main menu
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }

        } while (choice != 11);
    }

    // =========================== Customers Menu ========================

    private static void customersMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println("1. Register new customer");
            System.out.println("2. Search for Customer (IDs)");
            System.out.println("3. Place New Order for specific customer");
            System.out.println("4. Order history for specific customer");
            System.out.println("5. List All Customers Sorted Alphabetically.");
            System.out.println("6. Extract reviews from a specific customer for all products.");
            System.out.println("7. List All Customers");
            System.out.println("8. Return Main menu");
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1: { // Register new customer
                    int id = readInt("Enter customer ID: ");
                    System.out.print("Enter customer name: ");
                    String name = input.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = input.nextLine();
                    CustomerNode c = new CustomerNode(id, name, email);
                    customersDS.addCustomer(c);
                    break;
                }

                case 2: { // Search customer by ID
                    int id = readInt("Enter customer ID: ");
                    CustomerNode c = customersDS.searchById(id);
                    if (c == null) System.out.println("Customer not found.");
                    else c.displayBasic();
                    break;
                }

                case 3: { // Place New Order for specific customer
                    int cid = readInt("Enter customer ID: ");
                    ordersDS.placeNewOrder(cid, productsDS, customersDS);
                    break;
                }

                case 4: { // Order history for specific customer
                	int cid = readInt("Enter customer ID: ");
                	ordersDS.placeNewOrder(cid, productsDS, customersDS);

                }

                case 5: // List all customers sorted alphabetically
                    customersDS.listCustomersAlphabetically();
                    break;

                case 6: { // Extract reviews from a specific customer
                    int cid = readInt("Enter customer ID: ");
                    customersDS.printReviewsForCustomer(cid);
                    break;
                }

                case 7: // List all customers
                    customersDS.displayAllCustomers();
                    break;

                case 8:
                    // Return main menu
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }

        } while (choice != 8);
    }

    // ============================= Orders Menu =========================

    private static void ordersMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println("1. Place New Order");
            System.out.println("2. Cancel Order");
            System.out.println("3. Update Order status");
            System.out.println("4. Search By ID");
            System.out.println("5. All orders between two dates");
            System.out.println("6. Return Main menu");
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1: { // Place new order
                    int cid = readInt("Enter customer ID: ");
                    ordersDS.placeNewOrder(cid, productsDS, customersDS);
                    break;
                }

                case 2: { // Cancel order
                    int oid = readInt("Enter order ID to cancel: ");
                    ordersDS.cancelOrder(oid);
                    break;
                }

                case 3: { // Update status
                    int oid = readInt("Enter order ID to update: ");
                    System.out.print("Enter new status: ");
                    String status = input.nextLine();
                    ordersDS.updateOrderStatus(oid, status);
                    break;
                }

                case 4: { // Search by ID
                    int oid = readInt("Enter order ID: ");
                    OrderNode o = ordersDS.searchById(oid);
                    if (o == null) System.out.println("Order not found.");
                    else o.display();
                    break;
                }

                case 5: { // All orders between two dates
                    LocalDate d1 = readDate("Enter start date (yyyy-MM-dd): ");
                    LocalDate d2 = readDate("Enter end date   (yyyy-MM-dd): ");
                    ordersDS.findOrdersBetweenDates(d1, d2);
                    break;
                }

                case 6:
                    // Return main menu
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }

        } while (choice != 6);
    }

    // ============================ Reviews Menu =========================

    private static void reviewsMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println("1. Add review");
            System.out.println("2. Edit review (rating , comment)");
            System.out.println("3. Get an average rating for product");
            System.out.println("4. Show the Top 3 Highest AVG Rated Products _new");
            System.out.println("5. Show the Top 3 Most Reviewed.");
            System.out.println("6. Common products with an average rating 4 and more between 2 customers");
            System.out.println("7. Return Main menu");
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1: { // Add review
                    int rid = readInt("Enter review ID: ");
                    int pid = readInt("Enter product ID: ");
                    int cid = readInt("Enter customer ID: ");
                    int rating = readInt("Enter rating (1-5): ");
                    System.out.print("Enter comment: ");
                    String comment = input.nextLine();
                    ReviewNode r = new ReviewNode(rid, pid, cid, rating, comment);
                    reviewsDS.addReview(r);
                    break;
                }

                case 2: { // Edit review
                    int rid = readInt("Enter review ID to edit: ");
                    int rating = readInt("Enter new rating (1-5): ");
                    System.out.print("Enter new comment: ");
                    String comment = input.nextLine();
                    reviewsDS.editReview(rid, rating, comment);
                    break;
                }

                case 3: { // Average rating
                    int pid = readInt("Enter product ID: ");
                    reviewsDS.getAverageRating(pid);
                    break;
                }

                case 4: // Top 3 highest AVG rated products
                    reviewsDS.suggestTop3Products();
                    break;

                case 5: // Top 3 most reviewed
                    reviewsDS.showTop3MostReviewed();
                    break;

                case 6: { // Common products avg rating >=4 between 2 customers
                    int c1 = readInt("Enter first customer ID: ");
                    int c2 = readInt("Enter second customer ID: ");
                    reviewsDS.commonProductsWithRatingAtLeast4BetweenCustomers(c1, c2);
                    break;
                }

                case 7:
                    // Return main menu
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }

        } while (choice != 7);
    }

    // ============================ Helpers ===============================

    private static int readInt(String msg) {
        while (true) {
            try {
                System.out.print(msg);
                String line = input.nextLine();
                return Integer.parseInt(line.trim());
            } catch (Exception e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static double readDouble(String msg) {
        while (true) {
            try {
                System.out.print(msg);
                String line = input.nextLine();
                return Double.parseDouble(line.trim());
            } catch (Exception e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static LocalDate readDate(String msg) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        while (true) {
            try {
                System.out.print(msg);
                String line = input.nextLine();
                return LocalDate.parse(line.trim(), fmt);
            } catch (Exception e) {
                System.out.println("Invalid date format, try again (yyyy-MM-dd).");
            }
        }
    }
}
