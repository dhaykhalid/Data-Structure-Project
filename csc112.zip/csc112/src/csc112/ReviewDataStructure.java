package csc112;

import java.io.File;
import java.util.Scanner;

public class ReviewDataStructure {
    private static LinkedList<ReviewNode> reviews;
    private ProductDataStructure all_products;
    private CustomerDataStructure all_Customers;

    // constructor with parameters
    public ReviewDataStructure(LinkedList<ReviewNode> reviews,
                               LinkedList<ProductNode> input_products,
                               LinkedList<CustomerNode> input_customers) {
        this.reviews = reviews;
        all_products = new ProductDataStructure(input_products);
        all_Customers = new CustomerDataStructure(input_customers);
    }

    // default constructor
    public ReviewDataStructure() {
        reviews = new LinkedList<>();
        all_products = new ProductDataStructure();
        all_Customers = new CustomerDataStructure();
    }

    // return all reviews
    public LinkedList<ReviewNode> get_all_Reviews() {
        return reviews;
    }

    // return all products
    public ProductDataStructure get_all_Products() {
        return all_products;
    }

    // search for a review by its ID
    public ReviewNode SearchReviewByid(int id) {
        if (reviews.empty()) {
            return null;
        } else {
            reviews.findFirst();
            while (true) {
                if (reviews.retrieve().getReviewId() == id)
                    return reviews.retrieve();
                if (reviews.last()) break;
                reviews.findNext();
            }
        }
        return null;
    }

    // connect review to product
    public void assign_to_product(ReviewNode r) {
        ProductNode p = all_products.SearchProductByid(r.getProductId());
        if (p != null) p.addReview(r);
    }

    // connect review to customer
    public void assign_to_customer(ReviewNode r) {
        CustomerNode p = all_Customers.searchById(r.getCustomerId());
        if (p != null) p.addReview(r);
    }

    // add new review if it doesn’t already exist
    public void addReview(ReviewNode r) {
        if (SearchReviewByid(r.getReviewId()) == null) {
            reviews.addLast(r);
            assign_to_product(r);
            assign_to_customer(r);
        } else {
            System.out.println("Review with ID " + r.getReviewId() + " already exists!");
        }
    }

    // update existing review
    public void updateReview(int id, ReviewNode p) {
        ReviewNode old = SearchReviewByid(id);
        if (old == null)
            System.out.println("Review does not exist to make an update!");
        else
            old.UpdateReview(p);
    }

    // display all reviews
    public void displayAllReviews() {
        System.out.println("✦ All Reviews ✦");
        if (reviews.empty()) {
            System.out.println("no reviews exist");
            return;
        } else {
            reviews.findFirst();
            while (true) {
                ReviewNode p = reviews.retrieve();
                p.display();
                System.out.println("✦────────────────────────────────✦");
                if (reviews.last()) break;
                reviews.findNext();
            }
        }
    }

    // convert one line from the file to a ReviewNode object
    public static ReviewNode convert_String_to_Review(String Line) {
        String[] a = Line.split(",", 5);
        ReviewNode r = new ReviewNode(
                Integer.parseInt(a[0].trim()),
                Integer.parseInt(a[1].trim()),
                Integer.parseInt(a[2].trim()),
                Integer.parseInt(a[3].trim()),
                a[4]
        );
        return r;
    }

    // load reviews from CSV file
    public void loadReviews(String fileName) {
        try {
            File f = new File(fileName);
            Scanner read = new Scanner(f);
            System.out.println("Reading file: " + fileName);
            System.out.println("✦────────────────────────────────✦");
            if (read.hasNextLine()) read.nextLine(); // skip header

            while (read.hasNextLine()) {
                String line = read.nextLine().trim();
                if (line.isEmpty()) continue;
                ReviewNode r = convert_String_to_Review(line);
                addReview(r);
            }

            read.close();
            System.out.println("✦────────────────────────────────✦");
            System.out.println("Reviews loaded successfully \n");
        } catch (Exception e) {
            System.out.println("Error while loading reviews: " + e.getMessage());
        }
    }

    // ✦✦ New method ✦✦
    // This method shows products that both customers rated high (avg > 4)
    public void showCommonHighRatedProducts(int c1, int c2) {
        System.out.println("✦ Common High Rated Products (Avg > 4) ✦");

        if (reviews.empty()) {
            System.out.println("no reviews exist");
            System.out.println("✦────────────────────────────────✦");
            return;
        }

        LinkedList<Integer> ids1 = new LinkedList<>();
        LinkedList<Integer> ids2 = new LinkedList<>();

        // go through all reviews and store product IDs for each customer
        reviews.findFirst();
        while (true) {
            ReviewNode r = reviews.retrieve();
            ProductNode p = all_products.SearchProductByid(r.getProductId());
            if (p != null && p.getAverageRating() > 4) {
                if (r.getCustomerId() == c1 && !ids1.exists(r.getProductId()))
                    ids1.addLast(r.getProductId());
                if (r.getCustomerId() == c2 && !ids2.exists(r.getProductId()))
                    ids2.addLast(r.getProductId());
            }
            if (reviews.last()) break;
            reviews.findNext();
        }

        boolean found = false;
        if (!ids1.empty()) {
            ids1.findFirst();
            while (true) {
                int pid = ids1.retrieve();
                if (ids2.exists(pid)) {
                    ProductNode p = all_products.SearchProductByid(pid);
                    if (p != null) {
                        System.out.println("Product ID: " + pid +
                                " | Name: " + p.getName() +
                                " | Avg Rating: " + String.format("%.2f", p.getAverageRating()));
                        found = true;
                    }
                }
                if (ids1.last()) break;
                ids1.findNext();
            }
        }

        if (!found) System.out.println("No common high-rated products found.");
        System.out.println("✦────────────────────────────────✦");
    }
}
