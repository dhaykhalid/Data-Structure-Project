package csc112;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class OrderDataStructure {
    private LinkedList<OrderNode> allOrders;
    private CustomerDataStructure allCustomers;
    static DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // constructor with parameters
    public OrderDataStructure(LinkedList<CustomerNode> inputCustomers, LinkedList<OrderNode> allOrders) {
        allCustomers = new CustomerDataStructure(inputCustomers);
        this.allOrders = allOrders;
    }

    // default constructor
    public OrderDataStructure() {
        allCustomers = new CustomerDataStructure();
        allOrders = new LinkedList<>();
    }

    // return all orders
    public LinkedList<OrderNode> getOrders() {
        return allOrders;
    }

    // search for an order by its ID
    public OrderNode searchOrderById(int id) {
        if (allOrders.empty()) return null;

        allOrders.findFirst();
        while (true) {
            OrderNode o = allOrders.retrieve();
            if (o.getOrderID() == id) return o;
            if (allOrders.last()) break;
            allOrders.findNext();
        }
        return null;
    }

    // update order status
    public void UpdateOrderState(int id, String newStatus) {
        if (allOrders.empty()) {
            System.out.println("No orders found");
            return;
        }

        allOrders.findFirst();
        while (true) {
            OrderNode o = allOrders.retrieve();
            if (o.getOrderID() == id) {
                o.setStatus(newStatus);
                System.out.println("Order " + id + " status updated to: " + newStatus);
                return;
            }
            if (allOrders.last()) break;
            allOrders.findNext();
        }
        System.out.println("Order ID not found");
    }

    // remove order by ID
    public void removeOrder(int id) {
        if (searchOrderById(id) != null) {
            allOrders.remove();
            System.out.println("Order removed: " + id);
        } else {
            System.out.println("Order ID not found");
        }
    }

    // link the order to a customer
    public void assign(OrderNode ord) {
        CustomerNode p = allCustomers.searchById(ord.getCustomerID());
        if (p == null)
            System.out.println("Customer with ID " + ord.getCustomerID() + " does not exist to assign this order");
        else
            p.addOrder(ord);
    }

    // add new order
    public void addOrder(OrderNode ord) {
        if (searchOrderById(ord.getOrderID()) == null) {
            allOrders.addLast(ord);
            assign(ord);
        } else {
            System.out.println("Order with ID " + ord.getOrderID() + " already exists");
        }
    }

    // convert line from file into OrderNode object
    public static OrderNode convertStringToProduct(String Line) {
        String a[] = Line.split(",");
        int orderId = Integer.parseInt(a[0].trim().replace("\"", ""));
        int customerId = Integer.parseInt(a[1].trim().replace("\"", ""));
        String productIds = a[2].trim().replace("\"", "");
        double totalPrice = Double.parseDouble(a[3]);
        LocalDate date = LocalDate.parse(a[4], df);
        String status = a[5].trim();

        return new OrderNode(orderId, customerId, productIds, totalPrice, date, status);
    }

    // load orders from file
    public void loadOrders(String fileName) {
        try {
            File f = new File(fileName);
            Scanner read = new Scanner(f);
            System.out.println("Reading file: " + fileName);
            System.out.println("✦────────────────────────────────✦");
            if (read.hasNextLine()) read.nextLine();

            while (read.hasNextLine()) {
                String line = read.nextLine().trim();
                OrderNode ord = convertStringToProduct(line);
                addOrder(ord);
            }

            read.close();
            System.out.println("File loaded successfully \n");
        } catch (Exception e) {
            System.out.println("Error loading orders: " + e.getMessage());
        }
    }

    // display all orders
    public void displayAllOrders() {
        if (allOrders.empty()) {
            System.out.println(" No orders found!");
            return;
        }

        System.out.println("OrderID\tCustomerID\tProductIDs\tTotalPrice\tDate\tStatus");
        System.out.println("✦────────────────────────────────✦");

        allOrders.findFirst();
        while (true) {
            OrderNode o = allOrders.retrieve();
            o.display();
            if (allOrders.last()) break;
            allOrders.findNext();
        }

        System.out.println("✦────────────────────────────────✦");
    }

    // ✦✦ New method ✦✦
    // display all orders between two dates
    public void DisplayAllOrders_between2dates(LocalDate d1, LocalDate d2) {
        if (allOrders.empty()) {
            System.out.println(" No orders found!");
            return;
        }

        System.out.println("✦ Orders between " + d1 + " and " + d2 + " ✦");
        System.out.println("✦────────────────────────────────✦");

        allOrders.findFirst();
        while (true) {
            OrderNode o = allOrders.retrieve();
            if (o.getOrderDate().compareTo(d1) >= 0 && o.getOrderDate().compareTo(d2) <= 0)
                o.display();
            if (allOrders.last()) break;
            allOrders.findNext();
        }

        System.out.println("✦────────────────────────────────✦");
    }

    void displayAllOrders_between2dates(LocalDate of, LocalDate of0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
