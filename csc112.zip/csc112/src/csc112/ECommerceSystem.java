package csc112;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ECommerceSystem {

    private static final String SEP = "------------------------------------";
    private static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static CustomerDataStructure allCustomers;
    private static OrderDataStructure allOrders;
    private static ProductDataStructure allProducts;
    private static ReviewDataStructure allReviews;

    public ECommerceSystem() {
        allCustomers = new CustomerDataStructure();
        allOrders = new OrderDataStructure();
        allProducts = new ProductDataStructure();
        allReviews = new ReviewDataStructure();
    }

    private static void Load_all() {
        System.out.println(SEP);
        System.out.println("Loading files ...");
        System.out.println(SEP);
        
        // جرب هذه المسارات بالترتيب
        String[] productPaths = {
            "src/csc112/products.csv",
            "products.csv",
            "src/products.csv"
        };
        
        String[] customerPaths = {
            "src/csc112/customers.csv", 
            "customers.csv",
            "src/customers.csv"
        };
        
        String[] orderPaths = {
            "src/csc112/orders.csv",
            "orders.csv", 
            "src/orders.csv"
        };
        
        String[] reviewPaths = {
            "src/csc112/reviews.csv",
            "reviews.csv",
            "src/reviews.csv"
        };
        
        // تحميل المنتجات
        boolean productsLoaded = false;
        for (String path : productPaths) {
            if (new java.io.File(path).exists()) {
                allProducts.loadProducts(path);
                productsLoaded = true;
                break;
            }
        }
        if (!productsLoaded) {
            System.out.println("Error: products.csv file not found in any location");
        }
        
        // تحميل العملاء
        boolean customersLoaded = false;
        for (String path : customerPaths) {
            if (new java.io.File(path).exists()) {
                allCustomers.loadCustomers(path);
                customersLoaded = true;
                break;
            }
        }
        if (!customersLoaded) {
            System.out.println("Error: customers.csv file not found in any location");
        }
        
        // تحميل الطلبات
        boolean ordersLoaded = false;
        for (String path : orderPaths) {
            if (new java.io.File(path).exists()) {
                allOrders.loadOrders(path);
                ordersLoaded = true;
                break;
            }
        }
        if (!ordersLoaded) {
            System.out.println("Error: orders.csv file not found in any location");
        }
        
        // تحميل التقييمات
        boolean reviewsLoaded = false;
        for (String path : reviewPaths) {
            if (new java.io.File(path).exists()) {
                allReviews.loadReviews(path);
                reviewsLoaded = true;
                break;
            }
        }
        if (!reviewsLoaded) {
            System.out.println("Error: reviews.csv file not found in any location");
        }
        
        System.out.println(SEP);
        System.out.println("File loading completed");
        System.out.println(SEP);
    }

    public static void main(String[] args) {
        new ECommerceSystem();
        Scanner input = new Scanner(System.in);
        int choice;

        System.out.println("E-Commerce Management System");
        System.out.println("CSC 212 Project");

        do {
            System.out.println(SEP);
            System.out.println("Main Menu");
            System.out.println(SEP);
            System.out.println("1) Load all files");
            System.out.println("2) Display data");
            System.out.println("3) Add / Update");
            System.out.println("4) Search / Remove");
            System.out.println("5) Reports");
            System.out.println("100) Exit");
            System.out.println(SEP);
            System.out.print("Enter choice: ");

            while (!input.hasNextInt()) { 
                System.out.print("Please enter a valid number: "); 
                input.next(); 
            }
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    Load_all();
                    break;

                case 2:
                    System.out.println(SEP);
                    System.out.println("Display Data");
                    System.out.println(SEP);
                    System.out.println("1) Customers  2) Orders  3) Products  4) Reviews");
                    System.out.println(SEP);
                    System.out.print("Choose what to display: ");
                    
                    while (!input.hasNextInt()) { 
                        System.out.print("Please enter a valid number: "); 
                        input.next(); 
                    }
                    int disp = input.nextInt();
                    
                    if (disp == 1) {
                        allCustomers.displayAll();
                    } else if (disp == 2) {
                        allOrders.displayAllOrders();
                    } else if (disp == 3) {
                        allProducts.displayAllProducts();
                    } else if (disp == 4) {
                        allReviews.displayAllReviews();
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 3:
                    System.out.println(SEP);
                    System.out.println("Add / Update Data");
                    System.out.println(SEP);
                    System.out.println("1) Add product  2) Add customer  3) Add order  4) Update product");
                    System.out.println(SEP);
                    System.out.print("Enter choice: ");
                    
                    while (!input.hasNextInt()) { 
                        System.out.print("Please enter a valid number: "); 
                        input.next(); 
                    }
                    int add = input.nextInt();

                    if (add == 1) {
                        System.out.print("Product ID: "); 
                        int id = input.nextInt();
                        input.nextLine();
                        System.out.print("Product name: "); 
                        String name = input.nextLine();
                        System.out.print("Price: "); 
                        double price = input.nextDouble();
                        System.out.print("Stock quantity: "); 
                        int stock = input.nextInt();
                        allProducts.addProduct(new ProductNode(id, name, price, stock));
                        System.out.println("Product added successfully");

                    } else if (add == 2) {
                        System.out.print("Customer ID: "); 
                        int id = input.nextInt();
                        input.nextLine();
                        System.out.print("Customer name: "); 
                        String name = input.nextLine();
                        System.out.print("Email: "); 
                        String email = input.nextLine();
                        allCustomers.addCustomer(new CustomerNode(id, name, email));
                        System.out.println("Customer added successfully");

                    } else if (add == 3) {
                        System.out.print("Order ID: "); 
                        int oid = input.nextInt();
                        System.out.print("Customer ID: "); 
                        int cid = input.nextInt();
                        input.nextLine();
                        System.out.print("Product IDs (example: 101;102;103): "); 
                        String prod = input.nextLine();
                        System.out.print("Total amount: "); 
                        double tot = input.nextDouble();
                        input.nextLine();
                        System.out.print("Date (yyyy-MM-dd): "); 
                        LocalDate d = LocalDate.parse(input.nextLine(), DF);
                        System.out.print("Status (Pending/Shipped/Delivered/Cancelled): "); 
                        String st = input.nextLine();
                        allOrders.addOrder(new OrderNode(oid, cid, prod, tot, d, st));
                        System.out.println("Order added successfully");

                    } else if (add == 4) {
                        System.out.print("Current product ID: "); 
                        int oldId = input.nextInt();
                        System.out.print("New ID: "); 
                        int nid = input.nextInt();
                        input.nextLine();
                        System.out.print("New name: "); 
                        String n = input.nextLine();
                        System.out.print("New price: "); 
                        double p = input.nextDouble();
                        System.out.print("New stock quantity: "); 
                        int s = input.nextInt();
                        allProducts.updateProduct(oldId, new ProductNode(nid, n, p, s));
                        System.out.println("Product updated successfully");
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 4:
                    System.out.println(SEP);
                    System.out.println("Search / Remove");
                    System.out.println(SEP);
                    System.out.println("1) Search product  2) Search order  3) Remove product  4) Remove order");
                    System.out.println(SEP);
                    System.out.print("Enter choice: ");
                    
                    while (!input.hasNextInt()) { 
                        System.out.print("Please enter a valid number: "); 
                        input.next(); 
                    }
                    int act = input.nextInt();

                    if (act == 1) {
                        System.out.print("Enter product ID: "); 
                        int id = input.nextInt();
                        ProductNode product = allProducts.SearchProductByid(id);
                        if (product != null) {
                            product.display();
                        } else {
                            System.out.println("Product not found!");
                        }
                    } else if (act == 2) {
                        System.out.print("Enter order ID: "); 
                        int id = input.nextInt();
                        OrderNode order = allOrders.searchOrderById(id);
                        if (order != null) {
                            order.display();
                        } else {
                            System.out.println("Order not found!");
                        }
                    } else if (act == 3) {
                        System.out.print("Enter product ID to remove: "); 
                        int id = input.nextInt();
                        allProducts.removeProduct(id);
                    } else if (act == 4) {
                        System.out.print("Enter order ID to remove: "); 
                        int id = input.nextInt();
                        allOrders.removeOrder(id);
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 5:
                    System.out.println(SEP);
                    System.out.println("Reports");
                    System.out.println(SEP);
                    System.out.println("1) Orders between dates  2) High rated products  3) Out of stock products");
                    System.out.println(SEP);
                    System.out.print("Choose report: ");
                    
                    while (!input.hasNextInt()) { 
                        System.out.print("Please enter a valid number: "); 
                        input.next(); 
                    }
                    int rep = input.nextInt();

                    if (rep == 1) {
                        input.nextLine();
                        System.out.print("Start date (yyyy-MM-dd): "); 
                        LocalDate d1 = LocalDate.parse(input.nextLine(), DF);
                        System.out.print("End date (yyyy-MM-dd): "); 
                        LocalDate d2 = LocalDate.parse(input.nextLine(), DF);
                        allOrders.DisplayAllOrders_between2dates(d1, d2);
                    } else if (rep == 2) {
                        System.out.print("First customer ID: "); 
                        int c1 = input.nextInt();
                        System.out.print("Second customer ID: "); 
                        int c2 = input.nextInt();
                        allReviews.showCommonHighRatedProducts(c1, c2);
                    } else if (rep == 3) {
                        allProducts.displayOutOfStock();
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 100:
                    System.out.println(SEP);
                    System.out.println("Goodbye! Thank you for using the system");
                    System.out.println(SEP);
                    break;

                default:
                    System.out.println(SEP);
                    System.out.println("Invalid choice! Please try again");
                    System.out.println(SEP);
            }

        } while (choice != 100);

        input.close();
    }
}