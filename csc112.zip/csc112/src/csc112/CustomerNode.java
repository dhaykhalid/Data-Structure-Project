/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package csc112;

/**
 *
 * @author Dalia
 */
public class CustomerNode {

    private int customerID;
    private String name;
    private String email;
    private LinkedList<OrderNode> OrderDataStructure;   // this is the order list of this customer

    public CustomerNode(int customerID, String name, String email) {
        this.customerID = customerID;
        this.name = name;
        this.email = email;
        this.OrderDataStructure = new LinkedList<>();
    }

    public int getCustomerID() {
        return customerID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public void addOrder(OrderNode r){
        OrderDataStructure.addLast(r);
    }

    public void display(){
        System.out.println("CustomerID: " + customerID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("✦────────────────────────────────✦");
    }

    public void displayAllOrders(){

        if(OrderDataStructure.empty()){
            System.out.println("There are no orders for the customer " + name);
            return;
        }

        System.out.println("Orders for " + name + ":");
        OrderDataStructure.findFirst();

        while(true){
            OrderNode o = OrderDataStructure.retrieve();
            o.display();

            if(OrderDataStructure.last())
                break;

            OrderDataStructure.findNext();
        }

        System.out.println("✦────────────────────────────────✦");
    }

    void addReview(ReviewNode r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
